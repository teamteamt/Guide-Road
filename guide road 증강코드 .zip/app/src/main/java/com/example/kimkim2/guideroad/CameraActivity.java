package com.example.kimkim2.guideroad;

        import android.app.Activity;
        import android.content.Context;
        import android.content.Intent;
        import android.os.Bundle;
        import android.view.Display;
        import android.view.ViewGroup.LayoutParams;
        import android.view.WindowManager;


public class CameraActivity extends Activity {

    CameraPreview mCameraPreview;
    CameraOverlayview mOverlayview=null;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mOverlayview=new CameraOverlayview(this);


        Intent intent = getIntent();
        String latitude_ds = intent.getStringExtra("latitude_id");
        String longitude_ds = intent.getStringExtra("longitude_id");
        String latitude_st = intent.getStringExtra("st_latitude_id");
        String longitude_st = intent.getStringExtra("st_longitude_id");

        mOverlayview.setCurrentPoint(Double.parseDouble(latitude_st),Double.parseDouble(longitude_st));
        mOverlayview.setDestinationPoint(Double.parseDouble(latitude_ds), Double.parseDouble(longitude_ds));
    }


    public void onResume() {
        super.onResume();

        mCameraPreview = new CameraPreview(this);
        mOverlayview=new CameraOverlayview(this);


        Display display = ((WindowManager) this
                .getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();
        int height = display.getHeight();
        int width = display.getWidth();

        mOverlayview.setOverlaySize(width,height);

        setContentView(mCameraPreview, new LayoutParams(width,
                height));
        addContentView(mOverlayview, new LayoutParams(width,
                height));


    }

    public void onPause() {
        if (mCameraPreview.inPreview) {
            mCameraPreview.camera.startPreview();
        }
        super.onPause();
    }

   /* protected void onDestroy() {
        super.onDestroy();
    }*/
}