package com.example.kimkim2.guideroad;

import java.util.List;

public interface OnFinishSearchListener {
    void onSuccess(List<Item> itemList);
    void onFail();
}
