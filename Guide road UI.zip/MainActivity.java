package com.example.guideroad;

import android.graphics.Rect;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.nhn.android.maps.NMapActivity;
import com.nhn.android.maps.NMapController;
import com.nhn.android.maps.NMapOverlay;
import com.nhn.android.maps.NMapOverlayItem;
import com.nhn.android.maps.NMapView;
import com.nhn.android.maps.NMapView.OnMapStateChangeListener;
import com.nhn.android.maps.NMapView.OnMapViewTouchEventListener;
import com.nhn.android.maps.maplib.NGeoPoint;
import com.nhn.android.maps.nmapmodel.NMapError;
import com.nhn.android.maps.overlay.NMapPOIdata;
import com.nhn.android.maps.overlay.NMapPOIitem;
import com.nhn.android.mapviewer.overlay.NMapCalloutOverlay;
import com.nhn.android.mapviewer.overlay.NMapOverlayManager;
import com.nhn.android.mapviewer.overlay.NMapPOIdataOverlay;


public class MainActivity extends NMapActivity implements OnMapStateChangeListener, OnMapViewTouchEventListener, NMapOverlayManager.OnCalloutOverlayListener
{
    public static final String API_KEY="xtET0FCKDoh7BRkSQ73g";
    NMapView mMapView = null;
    NMapController mMapController = null;
    LinearLayout MapContainer;
    NMapViewerResourceProvider mMapViewerResourceProvider = null;
    NMapOverlayManager mOverlayManager;
    NMapPOIdataOverlay.OnStateChangeListener onPOIdataStateChangeListener = null;

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);



// create map view
        //mMapView = new NMapView(this);


// set the activity content to the map view
        //MapContainer.addView(mMapView);
        setContentView(R.layout.activity_main);
        mMapView = (NMapView)findViewById(R.id.Nmap);

// set a registered API key for Open MapViewer Library
        mMapView.setApiKey(API_KEY);

// initialize map view
        mMapView.setClickable(true);

// register listener for map state changes
        mMapView.setOnMapStateChangeListener(this);
        mMapView.setOnMapViewTouchEventListener(this);
        mMapView.setBuiltInZoomControls(true,null);

// use map controller to zoom in/out, pan and set map center, zoom level etc.
        mMapController = mMapView.getMapController();

        // create resource provider (지도 위에 표시되는 오버레이 객체들을 관리)
        mMapViewerResourceProvider = new NMapViewerResourceProvider(this);

// create overlay manager
        mOverlayManager = new NMapOverlayManager(this, mMapView, mMapViewerResourceProvider);

        // NMapPOIdataOverlay 객체 생성(여러 개의 오버레이 아이템들을 하나의 오버레이 객체에서 관리하기위함)
        int markerId = NMapPOIflagType.PIN;

// set POI data (임시지정 주소였음)
        /* NMapPOIdata poiData = new NMapPOIdata(2, mMapViewerResourceProvider);
        poiData.beginPOIdata(2);
        poiData.addPOIitem(127.0630205, 37.5091300, "Pizza 777-111", markerId, 0);
        poiData.addPOIitem(127.061, 37.51, "Pizza 123-456", markerId, 0);
        poiData.endPOIdata(); */

        //int marker = NMapPOIflagType.PIN; // 길안내 선의 표시 테스트
        // set POI data
        NMapPOIdata poiData = new NMapPOIdata(0, mMapViewerResourceProvider);

        poiData.beginPOIdata(0);
        poiData.addPOIitem( 127.062722, 37.507214, "내 위치", markerId, 0);
        //poiData.addPOIitem(127.061, 37.51, "도로", markerId, 0);
       // poiData.addPOIitem(127.106279,37.366380, "도착지", NMapPOIflagType.TO, 0);
        poiData.endPOIdata(); // 길안내 선의 표시 테스트 끝

// create POI data overlay
        NMapPOIdataOverlay poiDataOverlay = mOverlayManager.createPOIdataOverlay(poiData, null);

        // show all POI data 해당 오버레이 객체에 포함된 전체 아이템이 화면에 표시되도록 지도 중심 및 축적 레벨을 변경하기 위함
        poiDataOverlay.showAllPOIdata(0);

        // set event listener to the overlay 아이템의 선택 상태 or 말풍선 선택되는 경우를 처리하는 이벤트 리스너
        poiDataOverlay.setOnStateChangeListener(onPOIdataStateChangeListener);

        // 오버레이 아이템 클릭시 표시되는 말풍선 오버레이 클래스 NMapCalloitOverlay 이벤트 리스너
        mOverlayManager.setOnCalloutOverlayListener((NMapOverlayManager.OnCalloutOverlayListener)this);

        /*NMapPathData pathData = new NMapPathData(9);  // 길안내 선의 표시 테스트
        pathData.initPathData();
        pathData.addPathPoint(127.108099, 37.366034, NMapPathLineStyle.TYPE_SOLID);
        //여기서 시작, 직선
        pathData.addPathPoint(127.108088, 37.366043,0);
        pathData.addPathPoint(127.108079, 37.365619,0);
        pathData.addPathPoint(127.107458, 37.365608,0);
        pathData.addPathPoint(127.107232, 37.365608,0);
        pathData.addPathPoint(127.106904, 37.365624,0);
        pathData.addPathPoint(127.105933, 37.365621,NMapPathLineStyle.TYPE_DASH);
        //점선
        pathData.addPathPoint(127.105929, 37.366378,0);
        pathData.addPathPoint(127.106279, 37.366380,0); // 선의 끝
        pathData.endPathData();
        NMapPathDataOverlay pathDataOverlay = mOverlayManager.createPathDataOverlay(pathData); // 길안내 선의 표시 테스트 끝*/
    }

    public void onCalloutClick(NMapPOIdataOverlay poiDataOverlay, NMapPOIitem item)
    {
        // [[TEMP]] handle a click event of the callout
        Toast.makeText(MainActivity.this, "onCalloutClick: " + item.getTitle(), Toast.LENGTH_LONG).show();
    }

    //클릭 이벤트 발생 시 호출되는 인터페이스는 밖에 구현
    public void onFocusChanged(NMapPOIdataOverlay poiDataOverlay, NMapPOIitem item)
    {
        if (item != null) {
            Log.i("NMAP", "onFocusChanged: " + item.toString());
        } else {
            Log.i("NMAP", "onFocusChanged: ");
        }
    }

    public NMapCalloutOverlay onCreateCalloutOverlay(NMapOverlay arg0, NMapOverlayItem arg1, Rect arg2) {
        // set your callout overlay
        return new NMapCalloutBasicOverlay(arg0, arg1, arg2);
    }

    public void onMapInitHandler(NMapView mapview, NMapError errorInfo)
    {
        if (errorInfo == null)
        { // success
            // mMapController.setMapCenter(new NGeoPoint(126.978371, 37.5666091), 11);
        } else
        { // fai.Log.e("NMap", "onMapInitHandler: error=" + errorInfo.toString());
        }
    }




    @Override
    public void onMapCenterChange(NMapView nMapView, NGeoPoint nGeoPoint) {

    }

    @Override
    public void onMapCenterChangeFine(NMapView nMapView) {

    }

    @Override
    public void onZoomLevelChange(NMapView nMapView, int i) {

    }

    @Override
    public void onAnimationStateChange(NMapView nMapView, int i, int i1) {

    }

    @Override
    public void onLongPress(NMapView nMapView, MotionEvent motionEvent) {

    }

    @Override
    public void onLongPressCanceled(NMapView nMapView) {

    }

    @Override
    public void onTouchDown(NMapView nMapView, MotionEvent motionEvent) {

    }

    @Override
    public void onTouchUp(NMapView nMapView, MotionEvent motionEvent) {

    }

    @Override
    public void onScroll(NMapView nMapView, MotionEvent motionEvent, MotionEvent motionEvent1) {

    }

    @Override
    public void onSingleTapUp(NMapView nMapView, MotionEvent motionEvent) {

    }

    //protected void onCreate(Bundle savedInstanceState) {
    //  super.onCreate(savedInstanceState);
    //setContentView(R.layout.activity_main);}
}

