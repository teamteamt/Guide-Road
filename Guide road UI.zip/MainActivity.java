package com.example.guideroad;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Rect;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.util.Log;
import android.view.MotionEvent;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.nhn.android.maps.NMapActivity;
import com.nhn.android.maps.NMapController;
import com.nhn.android.maps.NMapOverlay;
import com.nhn.android.maps.NMapOverlayItem;
import com.nhn.android.maps.NMapView;
import com.nhn.android.maps.NMapView.OnMapStateChangeListener;
import com.nhn.android.maps.NMapView.OnMapViewTouchEventListener;
import com.nhn.android.maps.maplib.NGeoPoint;
import com.nhn.android.maps.nmapmodel.NMapError;
import com.nhn.android.maps.overlay.NMapPOIdata;
import com.nhn.android.maps.overlay.NMapPOIitem;
import com.nhn.android.mapviewer.overlay.NMapCalloutOverlay;
import com.nhn.android.mapviewer.overlay.NMapOverlayManager;
import com.nhn.android.mapviewer.overlay.NMapPOIdataOverlay;

import java.io.IOException;
import java.util.List;
import java.util.Locale;


public class MainActivity extends NMapActivity implements OnMapStateChangeListener, OnMapViewTouchEventListener, NMapOverlayManager.OnCalloutOverlayListener {
    public static final String API_KEY = "xtET0FCKDoh7BRkSQ73g";
    NMapView mMapView = null;
    NMapController mMapController = null;
    LinearLayout MapContainer;
    NMapViewerResourceProvider mMapViewerResourceProvider = null;
    NMapOverlayManager mOverlayManager;
    NMapPOIdataOverlay.OnStateChangeListener onPOIdataStateChangeListener = null;

    //private NMapMyLocationOverlay mMyLocationOverlay;
    //private NMapLocationManager mMapLocationManager;
    //private NMapCompassManager mMapCompassManager;

    EditText my_location;
    Geocoder coder;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // set data provider listener
        //super.setMapDataProviderListener(onDataProviderListener);

        setContentView(R.layout.activity_main);
        mMapView = (NMapView) findViewById(R.id.Nmap);
        my_location = (EditText) findViewById(R.id.start_edit);
        //coder = new Geocoder(this);
        coder=new Geocoder(getApplicationContext(), Locale.KOREA);

// set a registered API key for Open MapViewer Library
        mMapView.setApiKey(API_KEY);

// initialize map view
        mMapView.setClickable(true);

// register listener for map state changes
        mMapView.setOnMapStateChangeListener(this);
        mMapView.setOnMapViewTouchEventListener(this);
        mMapView.setBuiltInZoomControls(true, null);

        // 지도에 대한 상태 변경 이벤트 연결
        mMapView.setOnMapStateChangeListener(this);

// use map controller to zoom in/out, pan and set map center, zoom level etc.
        mMapController = mMapView.getMapController();

        // create resource provider (지도 위에 표시되는 오버레이 객체들을 관리)
        mMapViewerResourceProvider = new NMapViewerResourceProvider(this);

// create overlay manager
        mOverlayManager = new NMapOverlayManager(this, mMapView, mMapViewerResourceProvider);

        // NMapPOIdataOverlay 객체 생성(여러 개의 오버레이 아이템들을 하나의 오버레이 객체에서 관리하기위함)

        //
        /* int markerId = NMapPOIflagType.PIN;

        // set POI data
        NMapPOIdata poiData = new NMapPOIdata(0, mMapViewerResourceProvider);

        poiData.beginPOIdata(0);
        poiData.addPOIitem(location.getLongitude(), location.getLatitude(), "내 위치", markerId, 0);
        poiData.endPOIdata(); // 길안내 선의 표시 테스트 끝

// create POI data overlay
        NMapPOIdataOverlay poiDataOverlay = mOverlayManager.createPOIdataOverlay(poiData, null);

        // show all POI data 해당 오버레이 객체에 포함된 전체 아이템이 화면에 표시되도록 지도 중심 및 축적 레벨을 변경하기 위함
        poiDataOverlay.showAllPOIdata(0);

        // set event listener to the overlay 아이템의 선택 상태 or 말풍선 선택되는 경우를 처리하는 이벤트 리스너
        poiDataOverlay.setOnStateChangeListener(onPOIdataStateChangeListener);*/

        // 오버레이 아이템 클릭시 표시되는 말풍선 오버레이 클래스 NMapCalloitOverlay 이벤트 리스너
        //mOverlayManager.setOnCalloutOverlayListener((NMapOverlayManager.OnCalloutOverlayListener) this);

       LocationManager locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);

        LocationListener locationListener = new LocationListener() {
            public void onLocationChanged(Location location) {
                List<Address> list = null;
                double latitude = location.getLatitude();
                double longitude = location.getLongitude();


               try
                {
                    list = coder.getFromLocation(Double.parseDouble(String.valueOf(latitude)),Double.parseDouble(String.valueOf(longitude)), 1);
                }
                catch (NumberFormatException e)
                {
                    e.printStackTrace();
                }

                catch (IOException e)
                {
                    my_location.setText("입출력오류 : " + e.getMessage());
                    e.printStackTrace();
                }
                if(list != null)
                    my_location.setText(list.get(0).getAddressLine(0).toString());

                //my_location.setText(location.getLongitude() +","+ location.getLatitude());

                NMapPOIdata poiData = new NMapPOIdata(0, mMapViewerResourceProvider);

                //int markerId = NMapPOIflagType.SPOT;
                poiData.beginPOIdata(0);
                poiData.addPOIitem(location.getLongitude(), location.getLatitude(), list.get(0).getAddressLine(0).toString(), NMapPOIflagType.FROM, 0);
                poiData.endPOIdata();
                NMapPOIdataOverlay poiDataOverlay = mOverlayManager.createPOIdataOverlay(poiData, null);
                poiDataOverlay.showAllPOIdata(0);
                poiDataOverlay.setOnStateChangeListener(onPOIdataStateChangeListener);
                poiDataOverlay.clear();
            }

            public void onStatusChanged(String provider, int status, Bundle extras) {
            }

            public void onProviderEnabled(String provider) {
            }

            public void onProviderDisabled(String provider) {
            }
        };


        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
        locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, locationListener);

    }

    public void onCalloutClick(NMapPOIdataOverlay poiDataOverlay, NMapPOIitem item)
    {
        // [[TEMP]] handle a click event of the callout
        Toast.makeText(MainActivity.this, "onCalloutClick: " + item.getTitle(), Toast.LENGTH_LONG).show();
    }

    //클릭 이벤트 발생 시 호출되는 인터페이스는 밖에 구현
    public void onFocusChanged(NMapPOIdataOverlay poiDataOverlay, NMapPOIitem item)
    {
        if (item != null) {
            Log.i("NMAP", "onFocusChanged: " + item.toString());
        } else {
            Log.i("NMAP", "onFocusChanged: ");
        }
    }

    public NMapCalloutOverlay onCreateCalloutOverlay(NMapOverlay arg0, NMapOverlayItem arg1, Rect arg2) {
        // set your callout overlay
        return new NMapCalloutBasicOverlay(arg0, arg1, arg2);
    }


        public void onMapInitHandler(NMapView mapview, NMapError errorInfo)
    {
        if (errorInfo == null)
        { // success
            //startMyLocation();현재위치로 이동
            // mMapController.setMapCenter(new NGeoPoint(126.978371, 37.5666091), 11);
        } else
        { android.util.Log.e("NMap", "onMapInitHandler: error=" + errorInfo.toString());
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
    }



    @Override
    public void onMapCenterChange(NMapView nMapView, NGeoPoint nGeoPoint) {

    }

    @Override
    public void onMapCenterChangeFine(NMapView nMapView) {

    }

    @Override
    public void onZoomLevelChange(NMapView nMapView, int i) {

    }

    @Override
    public void onAnimationStateChange(NMapView nMapView, int i, int i1) {

    }

    @Override
    public void onLongPress(NMapView nMapView, MotionEvent motionEvent) {

    }

    @Override
    public void onLongPressCanceled(NMapView nMapView) {

    }

    @Override
    public void onTouchDown(NMapView nMapView, MotionEvent motionEvent) {

    }

    @Override
    public void onTouchUp(NMapView nMapView, MotionEvent motionEvent) {

    }

    @Override
    public void onScroll(NMapView nMapView, MotionEvent motionEvent, MotionEvent motionEvent1) {

    }

    @Override
    public void onSingleTapUp(NMapView nMapView, MotionEvent motionEvent) {

    }
}

