package com.example.user.a3dexe;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;

import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.common.api.GoogleApiClient;

    class MyView extends View {
        public MyView(Context context) {
            super(context);
            setBackgroundColor(Color.WHITE);
        }

        protected void onDraw(Canvas canvas) {
            Paint paint = new Paint();

            Bitmap click1 = BitmapFactory.decodeResource(getResources(), R.drawable.click1);
            canvas.drawBitmap(click1, 200, 280, null);

            Bitmap click2 = BitmapFactory.decodeResource(getResources(), R.drawable.click2);
            canvas.drawBitmap(click2, 1450, 280, null);

            Bitmap location1 = BitmapFactory.decodeResource(getResources(), R.drawable.location1);
            canvas.drawBitmap(location1, 800, 50, null);

            Bitmap location2 = BitmapFactory.decodeResource(getResources(), R.drawable.location2);
            canvas.drawBitmap(location2, 2050, 50, null);



        }
    }

class ImageDisActivity extends ActionBarActivity {

@Override
public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    MyView w = new MyView(this);
    setContentView(w);
  }
}

