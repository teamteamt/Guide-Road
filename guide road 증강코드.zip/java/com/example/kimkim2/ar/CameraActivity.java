package com.example.kimkim2.ar;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.hardware.Camera;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.widget.TextView;


public class CameraActivity extends Activity {
    final static String TAG = "PAAR";
    SurfaceView cameraPreview;
    SurfaceHolder previewHolder;
    Camera camera;
    boolean inPreview;

    SensorManager sensorManager;
    LocationManager locationManager;

    int orientationSensor;
    float headingAngle;
    float pitchAngle;
    float rollAnlge;

    int accelerometerSensor;
    float xAxis;//x축
    float yAxis;//y축
    float zAxis;//z축

    double latitude;//위도
    double longitude;//경도

    TextView xAxisValue;
    TextView yAxisValue;
    TextView zAxisValue;
    TextView headingValue;
    TextView pitchValue;
    TextView rollValue;
    TextView longitudeValue;
    TextView latitudeValue;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        xAxisValue=(TextView)findViewById(R.id.xAxisValue);
        yAxisValue=(TextView)findViewById(R.id.yAxisValue);
        zAxisValue=(TextView)findViewById(R.id.zAxisValue);
        headingValue=(TextView)findViewById(R.id.headingValue);
        pitchValue=(TextView)findViewById(R.id.pitchValue);
        rollValue=(TextView)findViewById(R.id.rollValue);
        longitudeValue=(TextView)findViewById(R.id.longitudeValue);
        latitudeValue=(TextView)findViewById(R.id.latitudeValue);



        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        if (locationManager != null) {
            if (Build.VERSION.SDK_INT >= 23 &&checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                    || Build.VERSION.SDK_INT >= 23 &&checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,1000,1,locationListener);
            }
        }
      //(서비스제공자의 상수값, 업데이트간격,기기 움직이는 미터 단위의 최소거리, 알림을 받을 locationListener)
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        orientationSensor = Sensor.TYPE_ORIENTATION;
        accelerometerSensor = Sensor.TYPE_ACCELEROMETER;
        sensorManager.registerListener(sensorEventListener, sensorManager.getDefaultSensor(orientationSensor), SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(sensorEventListener, sensorManager.getDefaultSensor(accelerometerSensor), SensorManager.SENSOR_DELAY_NORMAL);

        inPreview = false;

        cameraPreview = (SurfaceView) findViewById(R.id.cameraPreview);
        previewHolder = cameraPreview.getHolder();
        previewHolder.addCallback(surfaceCallback);
        previewHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
    }

    LocationListener locationListener = new LocationListener() {
        @Override
        public void onLocationChanged(Location location) {
            //변경되는 location값 받는 메소드
            latitude = location.getLatitude();
            longitude = location.getLongitude();

            latitudeValue.setText(String.valueOf(latitude));
            longitudeValue.setText(String.valueOf(longitude));
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
        }

        @Override
        public void onProviderEnabled(String provider) {
        }

        @Override
        public void onProviderDisabled(String provider) {
        }
    };

    final SensorEventListener sensorEventListener = new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent sensorEvent) {
            if (sensorEvent.sensor.getType() == Sensor.TYPE_ORIENTATION)
            {
                headingAngle = sensorEvent.values[0];
                pitchAngle = sensorEvent.values[1];
                rollAnlge = sensorEvent.values[2];

                headingValue.setText(String.valueOf(headingAngle));
                pitchValue.setText(String.valueOf(pitchAngle));
                rollValue.setText(String.valueOf(rollAnlge));
            }
            else if (sensorEvent.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
                xAxis = sensorEvent.values[0];
                yAxis = sensorEvent.values[1];
                zAxis = sensorEvent.values[2];

                xAxisValue.setText(String.valueOf(xAxis));
                yAxisValue.setText(String.valueOf(yAxis));
                zAxisValue.setText(String.valueOf(zAxis));
            }
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {

        }
    };

    public void onResume() {
        super.onResume();

        if (locationManager != null) {
            if (Build.VERSION.SDK_INT >= 23 &&checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                    || Build.VERSION.SDK_INT >= 23 &&checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,1000,1,locationListener);
            }
        }
        sensorManager.registerListener(sensorEventListener, sensorManager.getDefaultSensor(orientationSensor),SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(sensorEventListener, sensorManager.getDefaultSensor(accelerometerSensor), SensorManager.SENSOR_DELAY_NORMAL);

        camera = Camera.open();
    }

    public void onPause()
    {
        if (inPreview) {
            camera.stopPreview();
        }

        if (locationManager != null) {
            if (Build.VERSION.SDK_INT >= 23 &&checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                    || Build.VERSION.SDK_INT >= 23 &&checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                locationManager.removeUpdates(locationListener);
            }
        }
        sensorManager.unregisterListener(sensorEventListener);
        camera.release();
        camera = null;

        inPreview = false;
        super.onPause();
    }

    private Camera.Size getBestPreviewSize(int width, int height, Camera.Parameters parameters) {//최적의 preview사이즈 계산 메소드
        Camera.Size result = null;
        for (Camera.Size size : parameters.getSupportedPreviewSizes()) {
            if(size.width<=width && size.height<=height)
            {
                if (result == null) {
                    result = size;
                }
            }
            else
            {
                int resultArea = result.width * result.height;
                int newArea = size.width * size.height;

                if (newArea > resultArea) {
                    result = size;
                }
            }
        }
        return result;
    }

    SurfaceHolder.Callback surfaceCallback = new SurfaceHolder.Callback() {//SurfaceView 준비되면 호출,카메라 설정 및 작동
        @Override
        public void surfaceCreated(SurfaceHolder holder) {
            if(camera == null) {
                camera = Camera.open();
            }
            try{
                previewHolder.setKeepScreenOn(true);//화면 켜짐 유지
                camera.setPreviewDisplay(previewHolder);
            }
            catch (Throwable t)
            {
                Log.e(TAG,"Exception in setPreviewDisplay()",t);//오류 시 로그 출력
            }
        }

        @Override
        public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {//surfaceVew가 안드로이드에 의해 변경될때 호출
            Camera.Parameters parameters = camera.getParameters();
            Camera.Size size=getBestPreviewSize(width,height,parameters);

            if(size!=null)
            {
                parameters.setPreviewSize(size.width,size.height);
                camera.setParameters(parameters);
                camera.startPreview();
                inPreview=true;
            }
        }

        @Override
        public void surfaceDestroyed(SurfaceHolder holder) {
            //SurfaceView가 종료될때 호출
        }
    };
}
