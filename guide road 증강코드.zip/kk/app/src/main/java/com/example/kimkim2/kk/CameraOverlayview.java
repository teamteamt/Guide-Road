package com.example.kimkim2.kk;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

/**
 * Created by kimkim2 on 2016-05-21.
 */
public class CameraOverlayview extends View implements SensorEventListener {

    SensorManager sensorManager;

    private String TAG = "PAAR";

    int orientationSensor;
    float headingAngle;
    float pitchAngle;
    float rollAnlge;

    int accelerometerSensor;
    float xAxis;//x축
    float yAxis;//y축
    float zAxis;//z축

    CameraActivity mContext;

    public CameraOverlayview(Context context) {
        super(context);
        mContext = (CameraActivity) context;

        initSensor(context);
    }

    public void onSensorChanged(SensorEvent sensorEvent) {
        if (sensorEvent.sensor.getType() == Sensor.TYPE_ORIENTATION) {
            headingAngle = sensorEvent.values[0];
            pitchAngle = sensorEvent.values[1];
            rollAnlge = sensorEvent.values[2];

            Log.d(TAG,"Heading="+String.valueOf(headingAngle));
            Log.d(TAG,"pitch="+String.valueOf(pitchAngle));
            Log.d(TAG,"roll="+String.valueOf(rollAnlge));

        } else if (sensorEvent.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            xAxis = sensorEvent.values[0];
            yAxis = sensorEvent.values[1];
            zAxis = sensorEvent.values[2];




            Log.d(TAG,"xAxis="+String.valueOf(xAxis));
            Log.d(TAG,"yAxis="+String.valueOf(yAxis));
            Log.d(TAG,"zAxis="+String.valueOf(zAxis));
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    public void initSensor(Context context) {
        sensorManager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
        orientationSensor = Sensor.TYPE_ORIENTATION;
        accelerometerSensor = Sensor.TYPE_ACCELEROMETER;
        sensorManager.registerListener(this, sensorManager.getDefaultSensor(orientationSensor), SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(this, sensorManager.getDefaultSensor(accelerometerSensor), SensorManager.SENSOR_DELAY_NORMAL);

    }

    protected void onDraw(Canvas canvas)
    {
        Paint paint = new Paint();
        Bitmap b = BitmapFactory.decodeResource(getResources(),R.drawable.palaceicon);
        canvas.drawBitmap(b,520,430,paint);
        canvas.drawBitmap(b,1500,430,paint);

        //paint.setColor(Color.RED);
        //canvas.drawCircle(520, 430, 20, paint);
        //canvas.drawCircle(1500,430,20,paint);
    }


}
